import axios from 'axios';
import { Employee, EmployeeInput } from '../types/employee';

const api = axios.create({ baseURL: '/api' });

interface ListResponse  { success: boolean; data: Employee[]; count: number }
interface SingleResponse { success: boolean; data: Employee }

export const employeeApi = {
  getAll:  () =>
    api.get<ListResponse>('/employees').then(r => r.data.data),

  getOne:  (id: string) =>
    api.get<SingleResponse>(`/employees/${id}`).then(r => r.data.data),

  create:  (payload: EmployeeInput) =>
    api.post<SingleResponse>('/employees', payload).then(r => r.data.data),

  update:  (id: string, payload: Partial<EmployeeInput>) =>
    api.put<SingleResponse>(`/employees/${id}`, payload).then(r => r.data.data),

  remove:  (id: string) =>
    api.delete(`/employees/${id}`).then(r => r.data),
};
