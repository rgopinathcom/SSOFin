import { useState, useEffect, useCallback } from 'react';
import { Employee, EmployeeInput } from '../types/employee';
import { employeeApi } from '../api/employees';

export const useEmployees = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading,   setLoading]   = useState(false);
  const [error,     setError]     = useState<string | null>(null);

  const fetchAll = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const data = await employeeApi.getAll();
      setEmployees(data);
    } catch {
      setError('Failed to load employees.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const create = async (payload: EmployeeInput): Promise<Employee> => {
    const emp = await employeeApi.create(payload);
    setEmployees(prev => [emp, ...prev]);
    return emp;
  };

  const update = async (id: string, payload: Partial<EmployeeInput>): Promise<Employee> => {
    const emp = await employeeApi.update(id, payload);
    setEmployees(prev => prev.map(e => e.id === id ? emp : e));
    return emp;
  };

  const remove = async (id: string): Promise<void> => {
    await employeeApi.remove(id);
    setEmployees(prev => prev.filter(e => e.id !== id));
  };

  return { employees, loading, error, fetchAll, create, update, remove };
};
