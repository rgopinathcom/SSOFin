import React, { useState } from 'react';
import { Employee, EmployeeInput } from './types/employee';
import { useEmployees } from './hooks/useEmployees';
import { EmployeeTable } from './components/EmployeeTable';
import { EmployeeForm }  from './components/EmployeeForm';
import { Modal }         from './components/Modal';

type View = 'list' | 'create' | 'edit';

export default function App() {
  const { employees, loading, error, create, update, remove } = useEmployees();
  const [view,    setView]    = useState<View>('list');
  const [editing, setEditing] = useState<Employee | null>(null);
  const [deleting,setDeleting]= useState<Employee | null>(null);
  const [toast,   setToast]   = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);

  const showToast = (msg: string, type: 'ok' | 'err' = 'ok') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const handleCreate = async (data: EmployeeInput) => {
    await create(data);
    setView('list');
    showToast('Employee added successfully!');
  };

  const handleUpdate = async (data: EmployeeInput) => {
    if (!editing) return;
    await update(editing.id, data);
    setEditing(null);
    setView('list');
    showToast('Employee updated successfully!');
  };

  const handleDelete = async () => {
    if (!deleting) return;
    try {
      await remove(deleting.id);
      showToast(`${deleting.first_name} ${deleting.last_name} removed.`);
    } catch {
      showToast('Failed to delete employee.', 'err');
    } finally {
      setDeleting(null);
    }
  };

  const openEdit = (emp: Employee) => { setEditing(emp); setView('edit'); };

  const activeCount     = employees.filter(e => e.status === 'Active').length;
  const deptCount       = new Set(employees.map(e => e.department).filter(Boolean)).size;
  const avgSalary       = employees.length
    ? Math.round(employees.reduce((s, e) => s + (e.salary ?? 0), 0) / employees.length)
    : 0;

  return (
    <div className="app">
      {/* ── Header ─────────────────────────────────────────────────── */}
      <header className="app-header">
        <div className="header-inner">
          <div className="logo-area">
            <div className="logo-mark">◈</div>
            <div>
              <h1 className="app-title">Employee Directory</h1>
              <p className="app-sub">Workforce management system</p>
            </div>
          </div>
          {view === 'list' && (
            <button className="btn-primary" onClick={() => setView('create')}>
              + Add Employee
            </button>
          )}
          {view !== 'list' && (
            <button className="btn-ghost" onClick={() => { setView('list'); setEditing(null); }}>
              ← Back to list
            </button>
          )}
        </div>
      </header>

      {/* ── Stats bar ──────────────────────────────────────────────── */}
      <div className="stats-bar">
        <div className="stat">
          <span className="stat-val">{employees.length}</span>
          <span className="stat-label">Total</span>
        </div>
        <div className="stat-divider" />
        <div className="stat">
          <span className="stat-val">{activeCount}</span>
          <span className="stat-label">Active</span>
        </div>
        <div className="stat-divider" />
        <div className="stat">
          <span className="stat-val">{deptCount}</span>
          <span className="stat-label">Departments</span>
        </div>
        <div className="stat-divider" />
        <div className="stat">
          <span className="stat-val">
            {avgSalary ? `$${(avgSalary / 1000).toFixed(0)}k` : '—'}
          </span>
          <span className="stat-label">Avg Salary</span>
        </div>
      </div>

      {/* ── Main content ───────────────────────────────────────────── */}
      <main className="app-main">
        {loading && (
          <div className="loading-state">
            <div className="spinner" />
            <p>Loading employees…</p>
          </div>
        )}
        {error && <div className="error-banner">{error}</div>}

        {!loading && view === 'list' && (
          <EmployeeTable
            employees={employees}
            onEdit={openEdit}
            onDelete={setDeleting}
          />
        )}

        {!loading && view === 'create' && (
          <div className="form-section">
            <div className="section-header">
              <h2>New Employee</h2>
              <p>Fill in the details below to add a new team member.</p>
            </div>
            <EmployeeForm
              onSubmit={handleCreate}
              onCancel={() => setView('list')}
            />
          </div>
        )}

        {!loading && view === 'edit' && editing && (
          <div className="form-section">
            <div className="section-header">
              <h2>Edit Employee</h2>
              <p>Updating record for {editing.first_name} {editing.last_name}.</p>
            </div>
            <EmployeeForm
              initial={editing}
              onSubmit={handleUpdate}
              onCancel={() => { setView('list'); setEditing(null); }}
            />
          </div>
        )}
      </main>

      {/* ── Delete confirmation modal ───────────────────────────────── */}
      {deleting && (
        <Modal title="Confirm Deletion" onClose={() => setDeleting(null)}>
          <div className="confirm-body">
            <div className="confirm-icon">⚠</div>
            <p>
              Are you sure you want to permanently remove{' '}
              <strong>{deleting.first_name} {deleting.last_name}</strong>?
              This action cannot be undone.
            </p>
            <div className="confirm-actions">
              <button className="btn-cancel" onClick={() => setDeleting(null)}>Cancel</button>
              <button className="btn-danger" onClick={handleDelete}>Yes, Delete</button>
            </div>
          </div>
        </Modal>
      )}

      {/* ── Toast ──────────────────────────────────────────────────── */}
      {toast && (
        <div className={`toast toast-${toast.type}`}>
          {toast.type === 'ok' ? '✓' : '✕'} {toast.msg}
        </div>
      )}
    </div>
  );
}
