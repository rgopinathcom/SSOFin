import React, { useState } from 'react';
import { Employee } from '../types/employee';

interface Props {
  employees: Employee[];
  onEdit:    (emp: Employee) => void;
  onDelete:  (emp: Employee) => void;
}

const STATUS_CLASS: Record<string, string> = {
  'Active':     'badge-active',
  'On Leave':   'badge-leave',
  'Terminated': 'badge-terminated',
};

const fmt = (n: number | null) =>
  n == null ? '—' : new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);

const fmtDate = (s: string | null) =>
  s ? new Date(s).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : '—';

export const EmployeeTable: React.FC<Props> = ({ employees, onEdit, onDelete }) => {
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<keyof Employee>('created_at');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const toggleSort = (key: keyof Employee) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const filtered = employees
    .filter(e => {
      const q = search.toLowerCase();
      return (
        e.first_name.toLowerCase().includes(q)  ||
        e.last_name.toLowerCase().includes(q)   ||
        e.email.toLowerCase().includes(q)        ||
        (e.department ?? '').toLowerCase().includes(q) ||
        (e.job_title ?? '').toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      const av = (a[sortKey] as string | number | null) ?? '';
      const bv = (b[sortKey] as string | number | null) ?? '';
      return sortDir === 'asc'
        ? String(av).localeCompare(String(bv))
        : String(bv).localeCompare(String(av));
    });

  const SortIcon = ({ col }: { col: keyof Employee }) =>
    sortKey === col ? (sortDir === 'asc' ? <>↑</> : <>↓</>) : <span className="sort-neutral">↕</span>;

  if (employees.length === 0) {
    return (
      <div className="empty-state">
        <div className="empty-icon">◎</div>
        <p>No employees yet. Add your first one!</p>
      </div>
    );
  }

  return (
    <div className="table-wrap">
      <div className="table-toolbar">
        <input
          className="search-input"
          type="search"
          placeholder="Search by name, email, department…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <span className="count-badge">{filtered.length} / {employees.length}</span>
      </div>

      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              {(['first_name', 'email', 'department', 'job_title', 'salary', 'start_date', 'status'] as (keyof Employee)[]).map(col => (
                <th key={col} onClick={() => toggleSort(col)} className="sortable">
                  {col.replace('_', ' ')} <SortIcon col={col} />
                </th>
              ))}
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={8} className="no-results">No results for "{search}"</td></tr>
            ) : filtered.map((emp, i) => (
              <tr key={emp.id} style={{ '--row-i': i } as React.CSSProperties}>
                <td>
                  <div className="name-cell">
                    <div className="avatar">{emp.first_name[0]}{emp.last_name[0]}</div>
                    <div>
                      <div className="name">{emp.first_name} {emp.last_name}</div>
                      <div className="phone">{emp.phone || '—'}</div>
                    </div>
                  </div>
                </td>
                <td className="mono">{emp.email}</td>
                <td>{emp.department || '—'}</td>
                <td>{emp.job_title  || '—'}</td>
                <td className="mono">{fmt(emp.salary)}</td>
                <td className="mono">{fmtDate(emp.start_date)}</td>
                <td><span className={`status-badge ${STATUS_CLASS[emp.status] ?? ''}`}>{emp.status}</span></td>
                <td>
                  <div className="action-btns">
                    <button className="btn-edit"   onClick={() => onEdit(emp)}>Edit</button>
                    <button className="btn-delete" onClick={() => onDelete(emp)}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
