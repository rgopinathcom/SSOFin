import React, { useState, useEffect } from 'react';
import { Employee, EmployeeInput, DEPARTMENTS, STATUSES } from '../types/employee';

interface Props {
  initial?: Employee | null;
  onSubmit: (data: EmployeeInput) => Promise<void>;
  onCancel: () => void;
}

const EMPTY: EmployeeInput = {
  first_name: '', last_name: '', email: '', phone: '',
  department: '', job_title: '', salary: null,
  start_date: '', status: 'Active', notes: '',
};

export const EmployeeForm: React.FC<Props> = ({ initial, onSubmit, onCancel }) => {
  const [form, setForm]       = useState<EmployeeInput>(EMPTY);
  const [errors, setErrors]   = useState<Partial<Record<keyof EmployeeInput, string>>>({});
  const [saving, setSaving]   = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);

  useEffect(() => {
    if (initial) {
      setForm({
        first_name: initial.first_name,
        last_name:  initial.last_name,
        email:      initial.email,
        phone:      initial.phone      ?? '',
        department: initial.department ?? '',
        job_title:  initial.job_title  ?? '',
        salary:     initial.salary,
        start_date: initial.start_date ? initial.start_date.slice(0, 10) : '',
        status:     initial.status,
        notes:      initial.notes      ?? '',
      });
    } else {
      setForm(EMPTY);
    }
    setErrors({});
    setApiError(null);
  }, [initial]);

  const set = (field: keyof EmployeeInput) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      setForm(prev => ({
        ...prev,
        [field]: field === 'salary'
          ? (e.target.value === '' ? null : Number(e.target.value))
          : e.target.value,
      }));
      if (errors[field]) setErrors(prev => ({ ...prev, [field]: undefined }));
    };

  const validate = (): boolean => {
    const errs: typeof errors = {};
    if (!form.first_name.trim()) errs.first_name = 'First name is required';
    if (!form.last_name.trim())  errs.last_name  = 'Last name is required';
    if (!form.email.trim())      errs.email      = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = 'Invalid email';
    if (form.salary !== null && form.salary < 0) errs.salary = 'Salary must be ≥ 0';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true); setApiError(null);
    try {
      await onSubmit(form);
    } catch (err: any) {
      setApiError(err?.response?.data?.message ?? 'An error occurred. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const field = (
    id: keyof EmployeeInput, label: string,
    type: string = 'text',
    required = false,
    placeholder = '',
  ) => (
    <div className="form-group">
      <label htmlFor={id}>
        {label}{required && <span className="required">*</span>}
      </label>
      <input
        id={id}
        type={type}
        value={(form[id] as string | number | null) ?? ''}
        onChange={set(id)}
        placeholder={placeholder}
        className={errors[id] ? 'input-err' : ''}
        step={type === 'number' ? '0.01' : undefined}
        min={type === 'number' ? '0' : undefined}
      />
      {errors[id] && <span className="err-msg">{errors[id]}</span>}
    </div>
  );

  return (
    <form className="emp-form" onSubmit={handleSubmit} noValidate>
      <div className="form-grid">
        {/* Field 1 */}
        {field('first_name', 'First Name', 'text', true, 'Alice')}
        {/* Field 2 */}
        {field('last_name',  'Last Name',  'text', true, 'Chen')}
        {/* Field 3 */}
        {field('email',      'Email',      'email', true, 'alice@company.com')}
        {/* Field 4 */}
        {field('phone',      'Phone',      'tel',   false, '+1 555-0100')}
        {/* Field 5 - Department select */}
        <div className="form-group">
          <label htmlFor="department">Department</label>
          <select id="department" value={form.department ?? ''} onChange={set('department')}>
            <option value="">— Select —</option>
            {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        {/* Field 6 */}
        {field('job_title',  'Job Title',  'text',   false, 'Senior Engineer')}
        {/* Field 7 */}
        {field('salary',     'Salary ($)', 'number', false, '85000')}
        {/* Field 8 */}
        {field('start_date', 'Start Date', 'date',   false)}
        {/* Field 9 - Status select */}
        <div className="form-group">
          <label htmlFor="status">
            Status<span className="required">*</span>
          </label>
          <select id="status" value={form.status} onChange={set('status')}>
            {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>
      {/* Field 10 - Notes textarea spans full width */}
      <div className="form-group full-width">
        <label htmlFor="notes">Notes</label>
        <textarea
          id="notes"
          value={form.notes ?? ''}
          onChange={set('notes')}
          placeholder="Any additional notes..."
          rows={3}
        />
      </div>

      {apiError && <p className="api-error">{apiError}</p>}

      <div className="form-actions">
        <button type="button" className="btn-cancel" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn-submit" disabled={saving}>
          {saving ? 'Saving…' : initial ? 'Update Employee' : 'Add Employee'}
        </button>
      </div>
    </form>
  );
};
