export type EmployeeStatus = 'Active' | 'On Leave' | 'Terminated';

export interface Employee {
  id:          string;
  first_name:  string;
  last_name:   string;
  email:       string;
  phone:       string | null;
  department:  string | null;
  job_title:   string | null;
  salary:      number | null;
  start_date:  string | null;
  status:      EmployeeStatus;
  notes:       string | null;
  created_at:  string;
  updated_at:  string;
}

export type EmployeeInput = Omit<Employee, 'id' | 'created_at' | 'updated_at'>;

export const DEPARTMENTS = [
  'Engineering', 'Design', 'Product', 'Marketing',
  'Sales', 'HR', 'Finance', 'Operations', 'Legal',
];

export const STATUSES: EmployeeStatus[] = ['Active', 'On Leave', 'Terminated'];
