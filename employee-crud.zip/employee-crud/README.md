# Employee Directory — Full-Stack CRUD

A production-ready CRUD application with React (TypeScript), Node.js (Express), and PostgreSQL — fully containerized with Docker.

---

## Tech Stack

| Layer      | Technology                                    |
|------------|-----------------------------------------------|
| Frontend   | React 18, TypeScript, Vite, Axios             |
| Backend    | Node.js, Express, TypeScript, Joi (validation)|
| Database   | PostgreSQL 16                                 |
| Container  | Docker, Docker Compose, Nginx (reverse proxy) |

---

## Project Structure

```
employee-crud/
├── docker-compose.yml          ← Orchestrates all 3 services
│
├── postgres/
│   └── init.sql                ← Schema + seed data (auto-runs on first boot)
│
├── backend/
│   ├── Dockerfile              ← Multi-stage build (builder → production)
│   ├── tsconfig.json
│   ├── package.json
│   ├── .env                    ← DB credentials (override via compose env vars)
│   └── src/
│       ├── index.ts            ← Express entry point
│       ├── config/
│       │   └── db.ts           ← pg.Pool connection
│       ├── models/
│       │   └── employee.model.ts  ← TypeScript interfaces
│       ├── middleware/
│       │   └── validate.ts     ← Joi request validation
│       ├── controllers/
│       │   └── employee.controller.ts  ← CRUD handlers
│       └── routes/
│           └── employee.routes.ts      ← Express router
│
└── frontend/
    ├── Dockerfile              ← Build Vite → Nginx serve
    ├── nginx.conf              ← SPA fallback + /api proxy
    ├── vite.config.ts
    ├── tsconfig.json
    ├── index.html
    └── src/
        ├── main.tsx            ← React entry point
        ├── App.tsx             ← Root component (view state machine)
        ├── styles.css          ← Full design system
        ├── types/
        │   └── employee.ts     ← Shared TypeScript types
        ├── api/
        │   └── employees.ts    ← Axios API layer
        ├── hooks/
        │   └── useEmployees.ts ← CRUD state management hook
        └── components/
            ├── EmployeeForm.tsx   ← 10-field create/edit form
            ├── EmployeeTable.tsx  ← Sortable/searchable data table
            └── Modal.tsx          ← Reusable dialog
```

---

## The 10 Form Fields

| # | Field       | Type     | Validation              |
|---|-------------|----------|-------------------------|
| 1 | First Name  | text     | Required, max 100       |
| 2 | Last Name   | text     | Required, max 100       |
| 3 | Email       | email    | Required, unique, valid |
| 4 | Phone       | tel      | Optional, max 30        |
| 5 | Department  | select   | Optional (9 options)    |
| 6 | Job Title   | text     | Optional, max 150       |
| 7 | Salary      | number   | Optional, ≥ 0           |
| 8 | Start Date  | date     | Optional, ISO date      |
| 9 | Status      | select   | Active/On Leave/Terminated |
|10 | Notes       | textarea | Optional, max 2000 chars|

---

## REST API Endpoints

| Method | Endpoint              | Description         |
|--------|-----------------------|---------------------|
| GET    | /api/employees        | List all employees  |
| GET    | /api/employees/:id    | Get one employee    |
| POST   | /api/employees        | Create employee     |
| PUT    | /api/employees/:id    | Update employee     |
| DELETE | /api/employees/:id    | Delete employee     |
| GET    | /health               | API health check    |

---

## Docker Setup — Step by Step

### Step 1 — Prerequisites

Install Docker Desktop (Mac/Windows) or Docker Engine + Compose (Linux).
Verify installation:

```bash
docker --version       # Docker 24+ recommended
docker compose version # Compose v2+
```

---

### Step 2 — Understanding the Architecture

```
Browser  ──→  frontend:80 (nginx)
                  │
                  ├── Static assets (React build)  served directly
                  │
                  └── /api/* requests  ──→  proxy_pass  ──→  backend:4000 (Express)
                                                                   │
                                                              postgres:5432
```

Three containers communicate over a shared Docker network (`employee-crud_default`):

- **postgres** — Stores data in a named volume (`employee_pg_data`) so data survives container restarts.
- **backend** — Waits for postgres to be healthy before starting (via `depends_on` + `healthcheck`).
- **frontend** — Nginx serves the built React app. `/api/*` requests are proxied to the backend container by hostname (`backend`). This means no CORS issues and no hardcoded IPs.

---

### Step 3 — Multi-Stage Dockerfiles

Both services use **multi-stage builds** to keep images small and secure:

**Backend Dockerfile:**
```
Stage 1 (builder): node:20-alpine
  → npm ci (installs ALL deps including devDependencies)
  → tsc (compiles TypeScript to /dist)

Stage 2 (production): node:20-alpine
  → npm ci --omit=dev (production deps only, no TypeScript compiler)
  → Copies only /dist from builder
  → Result: ~160MB instead of ~600MB
```

**Frontend Dockerfile:**
```
Stage 1 (builder): node:20-alpine
  → npm ci
  → vite build (produces /dist with optimized HTML/JS/CSS bundles)

Stage 2 (production): nginx:1.25-alpine
  → Copies /dist into nginx html root
  → Uses custom nginx.conf for SPA routing + API proxy
  → Result: ~25MB image
```

---

### Step 4 — docker-compose.yml Explained

```yaml
services:
  postgres:
    healthcheck: ...          # Compose waits for pg_isready before marking healthy
    volumes:
      - pg_data:/var/lib/postgresql/data   # Named volume = persistent data
      - ./postgres/init.sql:/docker-entrypoint-initdb.d/init.sql
      # ↑ PostgreSQL auto-runs scripts in this directory on FIRST startup only

  backend:
    depends_on:
      postgres:
        condition: service_healthy   # Won't start until postgres passes healthcheck

  frontend:
    depends_on:
      backend:
        condition: service_healthy   # Won't start until backend passes healthcheck
```

Startup sequence is guaranteed: **postgres → backend → frontend**.

---

### Step 5 — Run the Application

```bash
# Clone / enter the project
cd employee-crud

# Build images and start all services (first run downloads base images ~2 min)
docker compose up --build

# Or run in detached (background) mode:
docker compose up --build -d
```

Open **http://localhost:3000** in your browser.

---

### Step 6 — Useful Commands

```bash
# View logs from all services
docker compose logs -f

# View logs from one service
docker compose logs -f backend

# Restart a single service (e.g., after code change)
docker compose up --build backend -d

# Stop all services (keeps volumes/data)
docker compose stop

# Stop and remove containers (keeps volumes/data)
docker compose down

# ⚠️ Stop, remove containers AND delete all data
docker compose down -v

# Shell into the backend container
docker exec -it emp_backend sh

# Connect to PostgreSQL directly
docker exec -it emp_postgres psql -U postgres -d employeedb
```

---

### Step 7 — Development Workflow (Hot Reload)

For local development with hot reload, bypass Docker for the services you're changing:

```bash
# 1. Start only PostgreSQL in Docker
docker compose up postgres -d

# 2. Run backend locally with hot reload
cd backend
npm install
npm run dev           # ts-node-dev watches for changes

# 3. Run frontend locally with hot reload
cd frontend
npm install
npm run dev           # Vite dev server on http://localhost:3000
```

Update `backend/.env` to use `DB_HOST=localhost` for local development.

---

## Environment Variables

| Variable      | Default       | Description             |
|---------------|---------------|-------------------------|
| PORT          | 4000          | Express server port     |
| DB_HOST       | postgres      | PostgreSQL hostname      |
| DB_PORT       | 5432          | PostgreSQL port          |
| DB_USER       | postgres      | Database user            |
| DB_PASSWORD   | postgres123   | Database password        |
| DB_NAME       | employeedb    | Database name            |
| NODE_ENV      | production    | Node environment         |

For production, override these in `docker-compose.yml` or use Docker secrets.

---

## Data Persistence

Employee data is stored in a **Docker named volume** (`employee_pg_data`). This means:

- ✅ `docker compose stop` → data preserved
- ✅ `docker compose down` → data preserved  
- ❌ `docker compose down -v` → data deleted (volume removed)

To back up your data:
```bash
docker exec emp_postgres pg_dump -U postgres employeedb > backup.sql
```

To restore:
```bash
cat backup.sql | docker exec -i emp_postgres psql -U postgres -d employeedb
```
