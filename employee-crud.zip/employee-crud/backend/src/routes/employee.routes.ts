import { Router } from 'express';
import {
  getEmployees,
  getEmployee,
  createEmployee,
  updateEmployee,
  deleteEmployee,
} from '../controllers/employee.controller';
import { validateEmployee } from '../middleware/validate';

const router = Router();

router.get('/',     getEmployees);
router.get('/:id',  getEmployee);
router.post('/',    validateEmployee, createEmployee);
router.put('/:id',  validateEmployee, updateEmployee);
router.delete('/:id', deleteEmployee);

export default router;
