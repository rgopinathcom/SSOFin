import { Request, Response } from 'express';
import pool from '../config/db';
import { EmployeeInput } from '../models/employee.model';

// ─── GET ALL ────────────────────────────────────────────────────────────────
export const getEmployees = async (_req: Request, res: Response): Promise<void> => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM employees ORDER BY created_at DESC'
    );
    res.json({ success: true, data: rows, count: rows.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// ─── GET ONE ────────────────────────────────────────────────────────────────
export const getEmployee = async (req: Request, res: Response): Promise<void> => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM employees WHERE id = $1',
      [req.params.id]
    );
    if (!rows.length) {
      res.status(404).json({ success: false, message: 'Employee not found' });
      return;
    }
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// ─── CREATE ─────────────────────────────────────────────────────────────────
export const createEmployee = async (req: Request, res: Response): Promise<void> => {
  const body: EmployeeInput = req.body;
  try {
    const { rows } = await pool.query(
      `INSERT INTO employees
        (first_name, last_name, email, phone, department, job_title,
         salary, start_date, status, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING *`,
      [
        body.first_name, body.last_name, body.email,
        body.phone       || null,
        body.department  || null,
        body.job_title   || null,
        body.salary      ?? null,
        body.start_date  || null,
        body.status      || 'Active',
        body.notes       || null,
      ]
    );
    res.status(201).json({ success: true, data: rows[0] });
  } catch (err: any) {
    if (err.code === '23505') {
      res.status(409).json({ success: false, message: 'Email already exists' });
      return;
    }
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// ─── UPDATE ─────────────────────────────────────────────────────────────────
export const updateEmployee = async (req: Request, res: Response): Promise<void> => {
  const body: Partial<EmployeeInput> = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE employees SET
        first_name  = COALESCE($1, first_name),
        last_name   = COALESCE($2, last_name),
        email       = COALESCE($3, email),
        phone       = COALESCE($4, phone),
        department  = COALESCE($5, department),
        job_title   = COALESCE($6, job_title),
        salary      = COALESCE($7, salary),
        start_date  = COALESCE($8, start_date),
        status      = COALESCE($9, status),
        notes       = COALESCE($10, notes)
       WHERE id = $11
       RETURNING *`,
      [
        body.first_name, body.last_name, body.email,
        body.phone, body.department, body.job_title,
        body.salary, body.start_date, body.status,
        body.notes, req.params.id,
      ]
    );
    if (!rows.length) {
      res.status(404).json({ success: false, message: 'Employee not found' });
      return;
    }
    res.json({ success: true, data: rows[0] });
  } catch (err: any) {
    if (err.code === '23505') {
      res.status(409).json({ success: false, message: 'Email already exists' });
      return;
    }
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

// ─── DELETE ─────────────────────────────────────────────────────────────────
export const deleteEmployee = async (req: Request, res: Response): Promise<void> => {
  try {
    const { rowCount } = await pool.query(
      'DELETE FROM employees WHERE id = $1',
      [req.params.id]
    );
    if (!rowCount) {
      res.status(404).json({ success: false, message: 'Employee not found' });
      return;
    }
    res.json({ success: true, message: 'Employee deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};
