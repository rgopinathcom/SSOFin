import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';

const employeeSchema = Joi.object({
  first_name: Joi.string().trim().max(100).required(),
  last_name:  Joi.string().trim().max(100).required(),
  email:      Joi.string().email().max(255).required(),
  phone:      Joi.string().trim().max(30).allow('', null).optional(),
  department: Joi.string().trim().max(100).allow('', null).optional(),
  job_title:  Joi.string().trim().max(150).allow('', null).optional(),
  salary:     Joi.number().min(0).max(9999999999.99).allow(null).optional(),
  start_date: Joi.string().isoDate().allow('', null).optional(),
  status:     Joi.string().valid('Active', 'On Leave', 'Terminated').optional(),
  notes:      Joi.string().max(2000).allow('', null).optional(),
});

export const validateEmployee = (req: Request, res: Response, next: NextFunction): void => {
  const { error } = employeeSchema.validate(req.body, { abortEarly: false });
  if (error) {
    res.status(400).json({
      success: false,
      errors: error.details.map((d) => d.message),
    });
    return;
  }
  next();
};
