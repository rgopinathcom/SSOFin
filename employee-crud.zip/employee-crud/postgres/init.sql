-- init.sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS employees (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  first_name  VARCHAR(100) NOT NULL,
  last_name   VARCHAR(100) NOT NULL,
  email       VARCHAR(255) UNIQUE NOT NULL,
  phone       VARCHAR(30),
  department  VARCHAR(100),
  job_title   VARCHAR(150),
  salary      NUMERIC(12, 2),
  start_date  DATE,
  status      VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active','On Leave','Terminated')),
  notes       TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER employees_updated_at
  BEFORE UPDATE ON employees
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Seed data
INSERT INTO employees (first_name, last_name, email, phone, department, job_title, salary, start_date, status, notes)
VALUES
  ('Alice',   'Chen',     'alice.chen@acme.com',    '555-0101', 'Engineering', 'Senior Engineer',       92000, '2021-03-15', 'Active',     'Lead on auth service'),
  ('Marcus',  'Rivera',   'marcus.r@acme.com',      '555-0102', 'Design',      'UX Designer',           78000, '2022-07-01', 'Active',     NULL),
  ('Priya',   'Sharma',   'priya.s@acme.com',       '555-0103', 'Engineering', 'Backend Engineer',      85000, '2020-11-20', 'Active',     NULL),
  ('James',   'Okafor',   'james.o@acme.com',       '555-0104', 'Marketing',   'Growth Analyst',        67000, '2023-01-10', 'On Leave',   'Parental leave until April'),
  ('Sofia',   'Martínez', 'sofia.m@acme.com',       '555-0105', 'Product',     'Product Manager',       99000, '2019-06-03', 'Active',     NULL);
